# Login

Login website is a app developed in javascript using React, Node, express ,HTML and CSS.
This project demonstrates user registration and login. Its purpose is to verify connectivity between the frontend and backend. 
This will learn about a simple front-end and back-end and you will know with the web structure we work with.

## Frontend
  -In the project directory, you can run:
  
    ### `npm start`
    
 - Runs the app in the development mode.
   
 - Open [http://localhost:3000](http://localhost:3000) to view it in your browser.
   
  -framework
  
     react

## Bakend
     -In the project directory, you can run:
     
        ### `node index.js`
        
    -framework
    
        node.js express mysql
        
    -db.sql 
    
     mysql install

# Details
  
  ## 1.HTML, CSS

  I learned about the HTML and CSS for a weeks.It is basics the web develop.web interface is made by HTML and CSS .
  
  In the  especially,CSS make great web interface. At the moment,I  don't know much about HTML and CSS function.
  
  But I know how it works. In the future, I will solve it by internet.

 ## 2.JAVASCRIPT

  JavaScript is a scripting or programming language that allows you to implement complex features on web pages.
  
  It is the third layer of the layer cake of standard web technologies.
  
  JavaScript is  that enables you to create dynamically updating content, control multimedia, animate images,
  
  and pretty much everything else. (Okay, not everything)

## 3.React

  React.js is an open-source JavaScript library,crafted with precision, that aims to simplify the intricate process
  
  of building interactive user interfaces.

  In React, you develop your applications by creating reusable components that you can think of as independent Lego blocks.
  
  These components are individual pieces of a final interface, which, when assembled, form the application’s entire user interface.  

  React’s primary role in an application is to handle the view layer of that application just like the V in a model-view-controller 
  (MVC) pattern by providing the best and most efficient rendering execution. 
  
  Rather than dealing with the whole user interface as a single unit, React.js encourages developers to separate these complex UIs 
  into individual reusable components that form the building blocks of the whole UI.
  
  In doing so, the ReactJS framework combines the speed and efficiency of JavaScript with a more efficient method of manipulating 
  the DOM to render web pages faster and create highly dynamic and responsive web applications.

## 4. Node and MySQL.
 ### 1.Node.
  Node (or more formally Node.js) is an open-source, cross-platform runtime environment that allows developers to create all kinds of server-side tools and applications in JavaScript.
  
  The environment omits browser-specific JavaScript APIs and adds support for more traditional OS APIs including HTTP and file system libraries.
  From a web server development perspective Node has a number of benefits.
  
  Great performance! Node was designed to optimize throughput and scalability in web applications and is a good solution for many common web-development problems.
  
  Code is written in "plain old JavaScript", which means that less time is spent dealing with "context shift" between languages when you're writing both client-side and server-side code.
 
### 2.MySQL
    MySQL is the most popular open source database. 
    
   MySQL powers many of the most accessed applications, including Facebook, Twitter, Netflix, Uber, Airbnb, Shopify, and Booking.com.
   
   MySQL is the most popular open source database. 
   
   MySQL powers many of the most accessed applications, including Facebook, Twitter, Netflix, Uber, Airbnb, Shopify, and Booking.com.
  Here is important, MySQL  should connect the Node.js.
  
  In order to that, MySQL's address ,usename,password should set and Node.js should insert it.

## 5. Tailwind CSS Project.

    I made web interface project using tailwind CSS for a week. 
    
  Tailwind CSS works by scanning all of your HTML files, JavaScript components, and any other templates for class names, generating the corresponding styles and then writing them to a static CSS file.
  
  The using tailwind CSS is made more fast than the HTML and CSS using.
  
  But , I didn't know this is framework using next.js.
  
  So, I found it difficult page route. 
  Also, I learned how responsive web site make and image Carousel

## 6. CryptozPay Project.

CryptozPay is an project providing cryptocurrency payment services.

This was made using the next.js and typescript.

TypeScript may be used to develop JavaScript applications for both client-side and server-side execution.

 Multiple options are available for transpilation. 
 
The default TypeScript Compiler can be used be invoked to convert TypeScript to JavaScript.

Also ,here is GraphQL.

GraphQL is a query language for your API, and a server-side runtime for executing queries using a type system you define for your data. 

GraphQL isn't tied to any specific database or storage engine and is instead backed by your existing code and data.

I did recieve and send  data using it.





  
