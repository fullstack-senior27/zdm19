let data = [
  {
    id: 1,
    name: "Guy Hawkins",
    pass: 27,
  },
  {
    id: 2,
    name: "Jane Cooper",
    pass: 19,
  },
  {
    id: 3,
    name: "Jacob Jones",
    pass: 32,
  },
  {
    id: 4,
    name: "Cody Fishers",
    pass: 29,
  },
  {
    id: 5,
    name: "Brooklyn Simmons",
    pass: 25,
  },
  {
    id: 6,
    name: "Esther Howard",
    pass: 26,
  },
  {
    id: 7,
    name: "Annette Black",
    pass: 22,
  },
  {
    id: 8,
    name: "Marvin McKinney",
    pass: 30,
  },
];
export default data;